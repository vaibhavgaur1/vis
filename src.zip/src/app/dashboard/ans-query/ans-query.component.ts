import { Component } from '@angular/core';

@Component({
  selector: 'app-ans-query',
  templateUrl: './ans-query.component.html',
  styleUrls: ['./ans-query.component.css']
})
export class AnsQueryComponent {

}
