import { Component } from '@angular/core';

@Component({
  selector: 'app-view-assigned-query',
  templateUrl: './view-assigned-query.component.html',
  styleUrls: ['./view-assigned-query.component.css']
})
export class ViewAssignedQueryComponent {

}
